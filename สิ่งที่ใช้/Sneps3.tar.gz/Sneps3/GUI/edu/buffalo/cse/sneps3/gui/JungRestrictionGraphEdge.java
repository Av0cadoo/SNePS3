/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.buffalo.cse.sneps3.gui;

/**
 *
 * @author dan
 */
public class JungRestrictionGraphEdge extends JungGraphEdge{
    public JungRestrictionGraphEdge(String label, JungGraphNode start, JungGraphNode end){
        super(label,start,end);
    }
}
