package edu.buffalo.cse.sneps3.gui;

import java.awt.Container;
import java.awt.FlowLayout;

// a do-nothing layout manager
class LazyLayout extends FlowLayout {

	LazyLayout(){
		super();
	}

	public void layoutContainer (Container target){
	}
	
	

}